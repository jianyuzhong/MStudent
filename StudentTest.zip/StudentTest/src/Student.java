import java.io.Serializable;


public class Student implements Serializable{
	private String number;
	private int score;
	public Student(String number,int score)
	{
		this.setNumber(number);
		this.setScore(score);
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public String ToString()
	{
		return "Student [number="+number+",score="+score+"]";
	}

}
