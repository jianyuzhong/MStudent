import java.awt.Choice;
import java.awt.List;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Random;


public class ChoiceDao {
	

	
	
	
	
	
    ArrayList<Chioce> chioces=new ArrayList<Chioce>();
	int []randomNumber=new int [4];
	public ArrayList<Chioce>getAllChioces()
	{
		try
		{
		readFormFile();
		}catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}catch(IOException e)
		{
			e.printStackTrace();
		}
		return chioces;
	}
	private void readFormFile() throws FileNotFoundException,IOException{
		String [] chioce=new String[6];
		Reader reader=new FileReader(new File("D:\\J_test\\JavaTest.txt"));
		BufferedReader bufferedReader=new BufferedReader(reader);
		String chioceString=null;
		
		while((chioceString=bufferedReader.readLine())!=null)
		{
			chioce=chioceString.split("!");
			shuffle();
			
			chioces.add(new Chioce(chioce[0],new String[]{
				chioce[randomNumber[0]],chioce[randomNumber[1]],
				chioce[randomNumber[2]],chioce[randomNumber[3]]
			},chioce[chioce.length-1]));
		}
		// TODO �Զ����ɵķ������
		
	}
	private void shuffle() {
		
		Random random=new Random();
		for(int i=0;i<randomNumber.length;i++)
		{
			randomNumber[i]=random.nextInt(4)+1;
			for(int j=0;j<=i-1;j++)
			{
				if(randomNumber[i]==randomNumber[j])
				{
					i--;
					break;
				}
			}
		}
		// TODO �Զ����ɵķ������
		
	}

}
