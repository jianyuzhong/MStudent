
public class StudentDao extends ObjectDao{
	public static void saveStudent(Student student,String fileName)
	{
		saveObject(student,fileName);
	}
	public static int getScore(Chioce chioce,String answer)
	{
		int score=0;
		String correctAnswer=chioce.getCorrectAnswer();
		if("A".equals(answer))
		{
			score=judge(chioce,0,correctAnswer);
			
		}else if("B".equals(answer))
		{
			score=judge(chioce,1,correctAnswer);
		}else if("C".equals(answer))
		{
			score=judge(chioce,2,correctAnswer);
		}else if("D".equals(answer))
		{
			score=judge(chioce,3,correctAnswer);
		}
		
		return score;
		
	}
	private static int judge(Chioce chioce,int i,String correctAnswer)
	{
		String userAnswer=chioce.getAnswers()[i];
		if(correctAnswer.equals(userAnswer))
		{
			return 2;
		}
		return 0;
	}
	

}
