import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;


public class ObjectDao {
	public static void saveObject(Object object,String fileName)
	{
		ObjectOutputStream oos=null;
		
		try {
			FileOutputStream fos=new FileOutputStream(new File(fileName+".dat"));
			oos=new ObjectOutputStream(fos);
			oos.writeObject(object);
		} catch (FileNotFoundException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		} catch (IOException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}finally
		{
			try {
				oos.close();
			} catch (IOException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
		}
		
	}
    public static Object readObject(String fileName)
    {
    	ObjectInputStream ois=null;
    	Object object=null;
    	
    	try {
			FileInputStream fis=new FileInputStream(new File(fileName));
			ois = new ObjectInputStream(fis);
			object =ois.readObject();
		} catch (FileNotFoundException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		} catch (IOException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}finally
		{
			try {
				ois.close();
			} catch (IOException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
		}
    	return object;
    }

}
