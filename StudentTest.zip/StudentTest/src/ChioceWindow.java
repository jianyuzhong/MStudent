import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;


public class ChioceWindow extends JFrame {
	
	private ArrayList<Chioce>chiocesList=new ArrayList<Chioce>();
	private JButton[] tihao=new JButton[10];
	private JComboBox[] chioces=new JComboBox[10];
	private ChoiceDao chioceDao=new ChoiceDao();
	private Chioce chioce=null;
	int j=0;
	private int score;

	public static void main(String[] args) {
		new ChioceWindow("ѡ����");
		
		// TODO �Զ����ɵķ������

	}
	public ChioceWindow(String title)
	{
		super(title);
		
	
		Toolkit tk=Toolkit.getDefaultToolkit();
		Dimension d=tk.getScreenSize();
		this.setSize(d.width/2,d.height/2);
		this.setLocation(d.width/4, d.height/4);
		
		this.setResizable(false);
		final JTextArea chioceArea=new JTextArea(10,15);
		chioceArea.setText("��ѡ����ţ�Ȼ������Ӧ��ź�����");
        chioceArea.setEnabled(false);
        this.add(chioceArea);
        JPanel timu=new JPanel();
        timu.setLayout(new GridLayout(2,1));
        JPanel tihaoPanel=new JPanel();
        tihaoPanel.setLayout(new GridLayout(1,10));
        JPanel chiocePanel=new JPanel();
        chiocePanel.setLayout(new GridLayout(1,10));
        chiocesList=chioceDao.getAllChioces();
        for(int i=0;i<tihao.length;i++)
        {
        	tihao[i]=new JButton("��"+(i+1)+"��");
        	tihaoPanel.add(tihao[i]);
            tihao[i].addActionListener(new ActionListener()
            {
            	@Override
            	public void actionPerformed(ActionEvent e)
            	{
            		chioceArea.setText("");
            		if(e.getActionCommand().equals("��10��"))
            		{
            			j=9;
            			chioce=chiocesList.get(9);
            		}
            		else
            		{
            			chioce=chiocesList.get(j);
            			chioce=chiocesList.get(e.getActionCommand().charAt(1)-49);
            		}
            		chioceArea.append(chioce.getQuestion()+"\n");
            		chioceArea.append("A."+chioce.getAnswers()[0]+"\n");
            		chioceArea.append("B."+chioce.getAnswers()[1]+"\n");
            		chioceArea.append("C."+chioce.getAnswers()[2]+"\n");
            		chioceArea.append("D."+chioce.getAnswers()[3]+"\n");
            		
            	}
            });
            chioces[i]=new JComboBox(new String []{"-","A","B","C","D"});
            chiocePanel.add(chioces[i]);
            
                  
        }
        timu.add(tihaoPanel);
        timu.add(chiocePanel);
        this.add(timu,"South");
        this.pack();
        this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setVisible(true);
        
        
	}
	@Override
	protected void processWindowEvent(WindowEvent e)
	{
		super.processWindowEvent(e);
		if(e.getID()==WindowEvent.WINDOW_CLOSING)
		{
			int result=JOptionPane.showConfirmDialog(this, "����𰸽���� \nע�⣺�����һ���������е���Ŀ\n"
					+ "ѡ���ǾͻḲ����ǰ�����Ľ��"
					+ "\nѡ��񲻻ᱣ���κ����ݡ�",
					"����",JOptionPane.YES_NO_CANCEL_OPTION
					);
			if(result==JOptionPane.YES_OPTION)
			{
				String number=JOptionPane.showInputDialog("���������ѧ��");
				
				ComputeScore();
				Student student=new Student(number,score);
				StudentDao.saveStudent(student, number);
				JOptionPane.showMessageDialog(this, "�ɹ�������","��Ϣ",JOptionPane.INFORMATION_MESSAGE);
				System.exit(1);
			}else if(result==JOptionPane.NO_OPTION)
			{
				JOptionPane.showMessageDialog(this, "���������","��Ϣ",JOptionPane.INFORMATION_MESSAGE);
			}else if(result==JOptionPane.CANCEL_OPTION)
			{
			
			}else
			{
				super.processWindowEvent(e);
			}
		}
	}
	public void ComputeScore()
	{
		for(int i=0;i<chioces.length;i++)
		{
			Chioce chioce=chiocesList.get(i);
			String answer=(String)chioces[i].getSelectedItem();
			score+=StudentDao.getScore(chioce, answer);
		}
	}

}
